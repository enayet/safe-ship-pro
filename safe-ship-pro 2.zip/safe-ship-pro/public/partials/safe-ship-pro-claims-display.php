<?php
/**
 * Claims page template for My Account.
 *
 * @since      1.0.0
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}
?>

<div class="safe-ship-pro-claims-page">
    <h2><?php esc_html_e( 'Shipping Protection Claims', 'safe-ship-pro' ); ?></h2>
    
    <?php
    // Handle new claim form
    if ( isset( $_GET['action'] ) && $_GET['action'] === 'new' && isset( $_GET['order_id'] ) ) {
        $order_id = intval( $_GET['order_id'] );
        $order = wc_get_order( $order_id );
        
        // Verify order belongs to current user and has protection
        if ( $order && $order->get_customer_id() === get_current_user_id() ) {
            // Check if order has protection in HPOS compatible way
            $has_protection = $order->get_meta( '_safe_ship_pro_protection_added', true ) === 'yes';
            
            if ( $has_protection ) {
                // Display new claim form
                ?>
                <div class="safe-ship-pro-new-claim">
                    <p><?php esc_html_e( 'Please provide details about your shipping issue to file a claim.', 'safe-ship-pro' ); ?></p>
                    
                    <form id="safe-ship-pro-claim-form" class="safe-ship-pro-claim-form" enctype="multipart/form-data">
                        <div class="safe-ship-pro-form-row">
                            <label for="order_id"><?php esc_html_e( 'Order', 'safe-ship-pro' ); ?></label>
                            <div class="safe-ship-pro-form-field">
                                <strong>#<?php echo esc_html( $order->get_order_number() ); ?></strong>
                                <input type="hidden" name="order_id" value="<?php echo esc_attr( $order_id ); ?>" />
                            </div>
                        </div>
                        
                        <div class="safe-ship-pro-form-row">
                            <label for="claim_type"><?php esc_html_e( 'Issue Type', 'safe-ship-pro' ); ?>*</label>
                            <div class="safe-ship-pro-form-field">
                                <select name="claim_type" id="claim_type" required>
                                    <option value=""><?php esc_html_e( '-- Select Issue Type --', 'safe-ship-pro' ); ?></option>
                                    <?php
                                    $claim_types = get_option( 'safe_ship_pro_claims_types', array(
                                        'damaged' => __( 'Damaged Package', 'safe-ship-pro' ),
                                        'lost' => __( 'Lost Package', 'safe-ship-pro' ),
                                        'stolen' => __( 'Stolen Package', 'safe-ship-pro' ),
                                        'delayed' => __( 'Delayed Delivery', 'safe-ship-pro' ),
                                        'other' => __( 'Other Issue', 'safe-ship-pro' ),
                                    ) );
                                    
                                    foreach ( $claim_types as $type_key => $type_label ) {
                                        echo '<option value="' . esc_attr( $type_key ) . '">' . esc_html( $type_label ) . '</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="safe-ship-pro-form-row">
                            <label for="claim_reason"><?php esc_html_e( 'Reason', 'safe-ship-pro' ); ?>*</label>
                            <div class="safe-ship-pro-form-field">
                                <textarea name="claim_reason" id="claim_reason" rows="5" required></textarea>
                                <p class="description"><?php esc_html_e( 'Please provide details about the issue and why you are filing a claim.', 'safe-ship-pro' ); ?></p>
                            </div>
                        </div>
                        
                        <div class="safe-ship-pro-form-row">
                            <label for="claim_files"><?php esc_html_e( 'Supporting Files', 'safe-ship-pro' ); ?></label>
                            <div class="safe-ship-pro-form-field">
                                <input type="file" name="claim_files[]" id="claim_files" multiple />
                                <p class="description"><?php esc_html_e( 'Optional. Upload photos or documents to support your claim. Accepted formats: JPG, PNG, PDF (Max 5MB each).', 'safe-ship-pro' ); ?></p>
                            </div>
                        </div>
                        
                        <div class="safe-ship-pro-form-row">
                            <div class="safe-ship-pro-form-submit">
                                <input type="hidden" name="action" value="safe_ship_pro_submit_claim" />
                                <input type="hidden" name="security" value="<?php echo esc_attr( wp_create_nonce( 'safe_ship_pro_submit_claim' ) ); ?>" />
                                <button type="submit" class="button"><?php esc_html_e( 'Submit Claim', 'safe-ship-pro' ); ?></button>
                                <a href="<?php echo esc_url( wc_get_account_endpoint_url( 'shipping-claims' ) ); ?>" class="button cancel"><?php esc_html_e( 'Cancel', 'safe-ship-pro' ); ?></a>
                                <span class="spinner"></span>
                            </div>
                        </div>
                        
                        <div id="claim-submission-result"></div>
                    </form>
                    
                    <!-- Debug Info (remove in production) -->
                    <?php if (defined('WP_DEBUG') && WP_DEBUG): ?>
                    <div class="debug-info" style="margin-top:20px; padding:10px; background:#f9f9f9; border:1px solid #eee;">
                        <h4>Debug Information:</h4>
                        <p>Form action: <?php echo admin_url('admin-ajax.php'); ?></p>
                        <p>User ID: <?php echo get_current_user_id(); ?></p>
                        <p>Order ID: <?php echo $order_id; ?></p>
                        <p>Has Protection: <?php echo $has_protection ? 'Yes' : 'No'; ?></p>
                    </div>
                    <?php endif; ?>
                </div>
                <?php
                return;
            } else {
                // Order doesn't have protection
                echo '<div class="woocommerce-message woocommerce-error">';
                esc_html_e( 'This order does not have shipping protection.', 'safe-ship-pro' );
                echo '</div>';
            }
        } else {
            // Invalid order
            echo '<div class="woocommerce-message woocommerce-error">';
            esc_html_e( 'Invalid order selected or order does not belong to your account.', 'safe-ship-pro' );
            echo '</div>';
        }
    }
    
    // List existing claims
    if ( ! empty( $claims ) ) {
        ?>
        <table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive safe-ship-pro-claims-table">
            <thead>
                <tr>
                    <th class="claim-id"><?php esc_html_e( 'Claim ID', 'safe-ship-pro' ); ?></th>
                    <th class="claim-date"><?php esc_html_e( 'Date', 'safe-ship-pro' ); ?></th>
                    <th class="claim-order"><?php esc_html_e( 'Order', 'safe-ship-pro' ); ?></th>
                    <th class="claim-type"><?php esc_html_e( 'Type', 'safe-ship-pro' ); ?></th>
                    <th class="claim-status"><?php esc_html_e( 'Status', 'safe-ship-pro' ); ?></th>
                    <th class="claim-actions"><?php esc_html_e( 'Actions', 'safe-ship-pro' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ( $claims as $claim ) {
                    // Get order info
                    $order = wc_get_order( $claim->order_id );
                    $order_number = $order ? $order->get_order_number() : $claim->order_id;
                    $order_url = $order ? $order->get_view_order_url() : '';
                    
                    // Claim type
                    $claim_types = array(
                        'damaged' => __( 'Damaged Package', 'safe-ship-pro' ),
                        'lost' => __( 'Lost Package', 'safe-ship-pro' ),
                        'stolen' => __( 'Stolen Package', 'safe-ship-pro' ),
                        'delayed' => __( 'Delayed Delivery', 'safe-ship-pro' ),
                        'other' => __( 'Other Issue', 'safe-ship-pro' ),
                    );
                    $claim_type = isset( $claim_types[$claim->claim_type] ) ? $claim_types[$claim->claim_type] : $claim->claim_type;
                    
                    // Status
                    $status_labels = array(
                        'pending' => __( 'Pending Review', 'safe-ship-pro' ),
                        'processing' => __( 'Processing', 'safe-ship-pro' ),
                        'approved' => __( 'Approved', 'safe-ship-pro' ),
                        'denied' => __( 'Denied', 'safe-ship-pro' ),
                        'completed' => __( 'Completed', 'safe-ship-pro' ),
                    );
                    $status_label = isset( $status_labels[$claim->claim_status] ) ? $status_labels[$claim->claim_status] : $claim->claim_status;
                    $status_class = 'status-' . sanitize_html_class( $claim->claim_status );
                    ?>
                    <tr>
                        <td class="claim-id" data-title="<?php esc_attr_e( 'Claim ID', 'safe-ship-pro' ); ?>">
                            <?php echo esc_html( $claim->id ); ?>
                        </td>
                        <td class="claim-date" data-title="<?php esc_attr_e( 'Date', 'safe-ship-pro' ); ?>">
                            <?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $claim->date_created ) ) ); ?>
                        </td>
                        <td class="claim-order" data-title="<?php esc_attr_e( 'Order', 'safe-ship-pro' ); ?>">
                            <a href="<?php echo esc_url( $order_url ); ?>">#<?php echo esc_html( $order_number ); ?></a>
                        </td>
                        <td class="claim-type" data-title="<?php esc_attr_e( 'Type', 'safe-ship-pro' ); ?>">
                            <?php echo esc_html( $claim_type ); ?>
                        </td>
                        <td class="claim-status" data-title="<?php esc_attr_e( 'Status', 'safe-ship-pro' ); ?>">
                            <span class="claim-status-badge <?php echo esc_attr( $status_class ); ?>"><?php echo esc_html( $status_label ); ?></span>
                        </td>
                        <td class="claim-actions" data-title="<?php esc_attr_e( 'Actions', 'safe-ship-pro' ); ?>">
                            <a href="#" class="button view-claim" data-claim-id="<?php echo esc_attr( $claim->id ); ?>">
                                <?php esc_html_e( 'View Details', 'safe-ship-pro' ); ?>
                            </a>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
        
        <!-- Claim Details Modal -->
        <div id="safe-ship-pro-claim-modal" class="safe-ship-pro-modal">
            <div class="safe-ship-pro-modal-content">
                <span class="safe-ship-pro-modal-close">&times;</span>
                <div id="safe-ship-pro-claim-details-content"></div>
            </div>
        </div>
        <?php
    } else {
        // No claims yet
        ?>
        <div class="woocommerce-message">
            <?php esc_html_e( 'You have not filed any shipping protection claims yet.', 'safe-ship-pro' ); ?>
        </div>
        <?php
    }
    
    // Show button to select order for new claim
    if ( ! empty( $protected_orders ) ) {
        ?>
        <div class="safe-ship-pro-new-claim-section">
            <h3><?php esc_html_e( 'File a New Claim', 'safe-ship-pro' ); ?></h3>
            <p><?php esc_html_e( 'Select an order to file a new shipping protection claim:', 'safe-ship-pro' ); ?></p>
            
            <form method="get" class="safe-ship-pro-select-order-form">
                <input type="hidden" name="ep_page" value="shipping-claims" />
                <input type="hidden" name="action" value="new" />
                <select name="order_id" required>
                    <option value=""><?php esc_html_e( 'Select an order...', 'safe-ship-pro' ); ?></option>
                    <?php
                    foreach ( $protected_orders as $order ) {
                        // Check if order already has a claim
                        $has_claim = false;
                        foreach ( $claims as $claim ) {
                            if ( $claim->order_id == $order->get_id() ) {
                                $has_claim = true;
                                break;
                            }
                        }
                        
                        echo '<option value="' . esc_attr( $order->get_id() ) . '"' . ( $has_claim ? ' disabled' : '' ) . '>';
                        echo '#' . esc_html( $order->get_order_number() ) . ' - ' . esc_html( date_i18n( get_option( 'date_format' ), strtotime( $order->get_date_created() ) ) );
                        
                        if ( $has_claim ) {
                            echo ' (' . esc_html__( 'Claim already filed', 'safe-ship-pro' ) . ')';
                        }
                        
                        echo '</option>';
                    }
                    ?>
                </select>
                <button type="submit" class="button"><?php esc_html_e( 'Continue', 'safe-ship-pro' ); ?></button>
            </form>
        </div>
        <?php
    } else {
        // No protected orders found
        ?>
        <div class="safe-ship-pro-new-claim-section">
            <h3><?php esc_html_e( 'File a New Claim', 'safe-ship-pro' ); ?></h3>
            <p><?php esc_html_e( 'You do not have any orders with shipping protection. Shipping protection must be added during checkout to be eligible for claims.', 'safe-ship-pro' ); ?></p>
        </div>
        <?php
    }
    ?>
</div>

<style>
    .safe-ship-pro-claims-table {
        margin-bottom: 30px;
    }
    
    .claim-status-badge {
        display: inline-block;
        padding: 3px 8px;
        border-radius: 3px;
        font-size: 12px;
        font-weight: bold;
    }
    
    .status-pending {
        background: #f8dda7;
        color: #94660c;
    }
    
    .status-processing {
        background: #c6e1c6;
        color: #5b841b;
    }
    
    .status-approved {
        background: #c8d7e1;
        color: #2e4453;
    }
    
    .status-denied {
        background: #eba3a3;
        color: #761919;
    }
    
    .status-completed {
        background: #c6e1c6;
        color: #5b841b;
    }
    
    .safe-ship-pro-new-claim-section {
        margin-top: 30px;
        padding: 20px;
        background: #f8f8f8;
        border: 1px solid #e5e5e5;
    }
    
    .safe-ship-pro-select-order-form {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .safe-ship-pro-select-order-form select {
        flex: 1;
    }
    
    .safe-ship-pro-claim-form .safe-ship-pro-form-row {
        margin-bottom: 20px;
    }
    
    .safe-ship-pro-claim-form label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }
    
    .safe-ship-pro-claim-form .description {
        font-size: 12px;
        color: #666;
        margin-top: 5px;
    }
    
    .safe-ship-pro-form-submit {
        display: flex;
        align-items: center;
    }
    
    .safe-ship-pro-form-submit .button.cancel {
        margin-left: 10px;
    }
    
    .safe-ship-pro-form-submit .spinner {
        background: url(../images/spinner.gif) no-repeat;
        background-size: 20px 20px;
        display: inline-block;
        visibility: hidden;
        vertical-align: middle;
        opacity: 0.7;
        width: 20px;
        height: 20px;
        margin: 0 10px;
    }
    
    .safe-ship-pro-form-submit .spinner.active {
        visibility: visible;
    }
    
    #claim-submission-result {
        margin-top: 15px;
    }
    
    /* Modal styles */
    .safe-ship-pro-modal {
        display: none;
        position: fixed;
        z-index: 999;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0, 0, 0, 0.4);
    }
    
    .safe-ship-pro-modal-content {
        background-color: #fefefe;
        margin: 10% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
        max-width: 600px;
        position: relative;
        border-radius: 3px;
    }
    
    .safe-ship-pro-modal-close {
        color: #aaa;
        position: absolute;
        top: 10px;
        right: 20px;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }
    
    .safe-ship-pro-modal-close:hover,
    .safe-ship-pro-modal-close:focus {
        color: black;
        text-decoration: none;
    }
    
    .safe-ship-pro-claim-detail-row {
        margin-bottom: 15px;
    }
    
    .safe-ship-pro-claim-detail-row h4 {
        margin: 0 0 5px 0;
    }
    
    /* Responsive adjustments */
    @media only screen and (max-width: 768px) {
        .safe-ship-pro-select-order-form {
            flex-direction: column;
            align-items: stretch;
            gap: 15px;
        }
        
        .safe-ship-pro-form-submit {
            flex-direction: column;
            align-items: stretch;
        }
        
        .safe-ship-pro-form-submit .button {
            width: 100%;
        }
        
        .safe-ship-pro-form-submit .button.cancel {
            margin-left: 0;
            margin-top: 10px;
        }
        
        .safe-ship-pro-form-submit .spinner {
            margin: 10px auto;
        }
        
        /* Make table responsive on mobile */
        .safe-ship-pro-claims-table th.claim-id,
        .safe-ship-pro-claims-table th.claim-date {
            display: none;
        }
        
        .safe-ship-pro-claims-table td.claim-id,
        .safe-ship-pro-claims-table td.claim-date {
            display: none;
        }
    }
</style>

<script type="text/javascript">
    jQuery(document).ready(function($) {
        // Claim submission
        $('#safe-ship-pro-claim-form').on('submit', function(e) {
            e.preventDefault();
            
            var form = $(this);
            var result = $('#claim-submission-result');
            var spinner = form.find('.spinner');
            var formData = new FormData(this);
            
            // Debug: Log form data
            if (window.console && window.console.log) {
                console.log('Form submitted');
                console.log('Ajax URL:', safe_ship_pro_claims.ajax_url);
                console.log('Form data:');
                for (var pair of formData.entries()) {
                    console.log(pair[0] + ': ' + pair[1]);
                }
            }
            
            // Validate form
            if (!form[0].checkValidity()) {
                form[0].reportValidity();
                return false;
            }
            
            // Confirm submission
            if (!confirm(safe_ship_pro_claims.i18n.confirm_submission)) {
                return false;
            }
            
            // Clear previous messages
            result.html('').removeClass('woocommerce-error woocommerce-message');
            
            // Show spinner
            spinner.addClass('active');
            
            // Disable submit button
            form.find('button[type="submit"]').prop('disabled', true);
            
            // Submit via AJAX
            $.ajax({
                url: safe_ship_pro_claims.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (window.console && window.console.log) {
                        console.log('AJAX response:', response);
                    }
                    
                    if (response.success) {
                        result.addClass('woocommerce-message').html(response.data.message);
                        
                        // Redirect to claims list after delay
                        setTimeout(function() {
                            window.location.href = wc_get_account_endpoint_url('shipping-claims');
                        }, 2000);
                    } else {
                        result.addClass('woocommerce-error').html(response.data.message);
                        form.find('button[type="submit"]').prop('disabled', false);
                    }
                },
                error: function(xhr, status, error) {
                    if (window.console && window.console.log) {
                        console.log('AJAX error:', error);
                        console.log('Status:', status);
                        console.log('Response:', xhr.responseText);
                    }
                    
                    result.addClass('woocommerce-error').html(safe_ship_pro_claims.i18n.error + (xhr.responseText ? ': ' + xhr.responseText : ''));
                    form.find('button[type="submit"]').prop('disabled', false);
                },
                complete: function() {
                    spinner.removeClass('active');
                }
            });
        });
        
        // View claim details modal
        $('.view-claim').on('click', function(e) {
            e.preventDefault();
            
            var claimId = $(this).data('claim-id');
            var modal = $('#safe-ship-pro-claim-modal');
            var contentContainer = $('#safe-ship-pro-claim-details-content');
            
            // Find claim details in the page
            var row = $(this).closest('tr');
            var claimDate = row.find('.claim-date').text().trim();
            var claimOrder = row.find('.claim-order').html();
            var claimType = row.find('.claim-type').text().trim();
            var claimStatus = row.find('.claim-status').html();
            
            // Generate content
            var content = '<h3>' + 'Claim Details #' + claimId + '</h3>';
            
            content += '<div class="safe-ship-pro-claim-detail-row">';
            content += '<h4>Date:</h4>';
            content += '<p>' + claimDate + '</p>';
            content += '</div>';
            
            content += '<div class="safe-ship-pro-claim-detail-row">';
            content += '<h4>Order:</h4>';
            content += '<p>' + claimOrder + '</p>';
            content += '</div>';
            
            content += '<div class="safe-ship-pro-claim-detail-row">';
            content += '<h4>Type:</h4>';
            content += '<p>' + claimType + '</p>';
            content += '</div>';
            
            content += '<div class="safe-ship-pro-claim-detail-row">';
            content += '<h4>Status:</h4>';
            content += '<p>' + claimStatus + '</p>';
            content += '</div>';
            
            content += '<div class="safe-ship-pro-claim-detail-row">';
            content += '<p>If you have any questions about your claim, please contact us.</p>';
            content += '</div>';
            
            // Set content and show modal
            contentContainer.html(content);
            modal.css('display', 'block');
        });
        
        // Close modal
        $('.safe-ship-pro-modal-close').on('click', function() {
            $('#safe-ship-pro-claim-modal').css('display', 'none');
        });
        
        // Close modal when clicking outside
        $(window).on('click', function(e) {
            if ($(e.target).is('.safe-ship-pro-modal')) {
                $('.safe-ship-pro-modal').css('display', 'none');
            }
        });
    });
</script>